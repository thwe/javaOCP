package pizza;

public interface Pizza {
	public abstract int getPrice();
	public abstract boolean isVegetable();
	public abstract boolean isHot();
}
