package pizza.bottom;

public class Crusty extends Bottom {
	
	public Crusty() {
		setPrice(340);
		setName ("Crusty");
	}
}
