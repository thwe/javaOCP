package pizza.bottom;

public class CuscinoSpeciale extends Bottom {
	
	public CuscinoSpeciale() {
		setPrice(495);
		setName ("CuscinoSpeciale");
	}
}
