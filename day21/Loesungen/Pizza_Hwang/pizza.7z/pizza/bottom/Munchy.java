package pizza.bottom;

public class Munchy extends Bottom {
	
	public Munchy () {
		setPrice(395);
		setName ("Munchy");
	}
}
