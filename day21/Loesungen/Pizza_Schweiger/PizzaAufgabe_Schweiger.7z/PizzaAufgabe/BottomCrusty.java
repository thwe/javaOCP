package PizzaAufgabe;

public class BottomCrusty extends Bottom {
	
	public int getPrice() {
		int price = 340;
		return price;
	}


}
