package PizzaAufgabe;

public class BottomCuscinoSpeciale extends Bottom {

	@Override
	public int getPrice() {
		int price = 495;
		return price;
	}



}
