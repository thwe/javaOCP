package PizzaAufgabe;

public class BottomMunchy extends Bottom {

	@Override
	public int getPrice() {
		int price = 395;
		return price;
	}


}
