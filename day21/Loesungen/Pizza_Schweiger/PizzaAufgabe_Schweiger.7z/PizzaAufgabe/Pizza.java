package PizzaAufgabe;

public interface Pizza {        
	
	public int getPrice(); // Preis in Cent         
	public boolean isVegetable(); // Pizza ist vegetarisch?         
	public boolean isHot(); // Pizza ist scharf?     } 
}
