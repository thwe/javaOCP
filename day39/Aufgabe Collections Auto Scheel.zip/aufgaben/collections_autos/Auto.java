package aufgaben.collections_autos;

import java.util.Comparator;

// 4. Comparable für LinkedList
abstract class Auto implements Comparable<Auto>{
	
	protected int baujahr;
	protected String modell;
	
	public Auto(String modell, int baujahr) {
		this.modell = modell;
		this.baujahr = baujahr;
	}
	
//	// compare() für Schnittstelle Comparator nötig
//	@Override
//	public int compare(Auto o1, Auto o2) {
//		int result = o1.modell.compareToIgnoreCase(o2.modell);
//		
//		if (result == 0)
//			return o1.baujahr - o2.baujahr;
//
//		return result;
//	}

	// 4. Sortieren von LinkedList. Hinweis: implements Comparable muss auch compareTo() implementieren
	// 4. Ordnen geschieht bereits beim hinzufügen zu TreeSet.
	public int compareTo(Auto o) {
		int result = modell.compareTo(o.modell);
		
		if (result == 0) {
			result =  baujahr - o.baujahr;
			}
		
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Auto other = (Auto) obj;
		if (baujahr != other.baujahr)
			return false;
		if (modell == null) {
			if (other.modell != null)
				return false;
		} else if (!modell.equals(other.modell))
			return false;
		return true;
	}

	// 7. Setter hinzufügen
	public void setBaujahr(int bj) {
		baujahr = bj;
	}

	// 4. HashSet benötigt hashCode()
	// Auto-Generate über Source->Generate...
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = baujahr * 989898989;
		result = prime * result + ((modell == null) ? 0 : modell.hashCode());
		return result;
	}

	// 3.
	@Override
	public String toString() {
		return getClass().getSimpleName() + ". Modell: " + modell + ", Baujahr " + baujahr;
		// Alternative zu 2.
		//return ". Modell: " + this.modell + ", Baujahr " + this.baujahr;
	}
	
	public static class DescendingOrder implements Comparator <Auto> {

		@Override
		public int compare(Auto o1, Auto o2) {
			int c = o2.modell.compareTo(o1.modell);
			if (c != 0)
				return c;
			else
				return o2.baujahr - o1.baujahr;
		}
	} 

}
