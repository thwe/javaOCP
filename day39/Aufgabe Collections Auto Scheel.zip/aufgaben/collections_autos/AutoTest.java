package aufgaben.collections_autos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.TreeSet;

public class AutoTest {

	public static void main(String[] args) {

		// 2.
		VW vw = new VW("Golf", 1990);
		BMW bmw = new BMW("Z4", 2000);

		System.out.println("2. ------------ Ausgabe mit System.out.println + @Override toString()) ------------");
		System.out.println(vw);
		System.out.println(bmw);
		
		// 3.
		VW vw1 = new VW("Polo", 2010);
		VW vw2 = new VW("Golf", 2011);
		VW vw3 = new VW("Passat", 2000);
		VW vw4 = new VW("Passat", 2001);
		VW vw5 = new VW("Passat", 1999);
		
		// 4.
		LinkedList<Auto> vwLL = new LinkedList<Auto>();
		vwLL.add(vw1);
		vwLL.add(vw2);
		vwLL.add(vw3);
		vwLL.add(vw4);
		vwLL.add(vw5);
		vwLL.add(vw1);
		Collections.sort(vwLL);		// 4. sortieren
		System.out.println("5. ------------ LinkedList<Auto> vwLL: --------------");
//		System.out.println(vwLL);
		for (Auto auto : vwLL) {	// 5. Ausgabe mit foreach
			System.out.println(auto);
		}
		
		HashSet<Auto> vwHS = new HashSet<Auto>();
		vwHS.add(vw1);
		vwHS.add(vw2);
		vwHS.add(vw3);
		vwHS.add(vw4);
		vwHS.add(vw5);
		vwHS.add(vw1);
		// 4. Sortieren: Workaround -> 1. in Liste wandeln, dann 2. sortieren
		ArrayList<Auto> listVwHS = new ArrayList<Auto>(vwHS);
		Collections.sort(listVwHS);
		System.out.println("5. ------- -----HashSet<Auto> vwHS:----- ---------");
		for (Auto auto : vwHS) {	// 5. Ausgabe mit foreach
			System.out.println(auto);
		}
		System.out.println("5. ------- -----ArrayList<Auto> listVwHS:----- ---------");
//		System.out.println(listVwHS);
		for (Auto auto : listVwHS) {	// 5. Ausgabe mit foreach
			System.out.println(auto);
		}
		
		TreeSet<Auto> vwTS = new TreeSet<Auto>();
		vwTS.add(vw1);				// 4. bereits beim hinzufügen sortiert durch compareTo()
		vwTS.add(vw2);
		vwTS.add(vw3);
		vwTS.add(vw4);
		vwTS.add(vw5);
		System.out.println("5. ------------ TreeSet<Auto> vwTS: --------------");
//		System.out.println(vwTS);	
		for (Auto auto : vwTS) {	// 5. Ausgabe mit foreach
			System.out.println(auto);
		}
		
		PriorityQueue<Auto> vwPQ = new PriorityQueue<Auto>();
		vwPQ.add(vw1);
		vwPQ.add(vw2);
		vwPQ.add(vw3);
		vwPQ.add(vw4);
		vwPQ.add(vw5);
		System.out.println("5. ------------ vorher: mit Iterator - PriorityQueue<Auto> vwPQ/vwAL: --------------");
		Iterator<Auto> iterator99 = vwPQ.iterator();
		while ( iterator99.hasNext() ) {
			Auto auto = iterator99.next();
			System.out.println(auto);
		}
	
//		Arrays.sort(vwPQ.toArray());
		System.out.println("5. ------------ PriorityQueue<Auto> vwPQ/vwAL: --------------");
//		System.out.println(vwPQ);
		// 4. Sortieren: Workaround -> 1. poll() um sortiert auszugeben, 2. in Array speichern, 3. Array ausgeben 
		ArrayList<Auto> vwAL = new ArrayList<Auto>();
		while (!vwPQ.isEmpty()) {
			Auto auto = vwPQ.poll();
			vwAL.add(auto);
		}
//		System.out.println(vwPQ.size());	// 0 - durch poll() geleert
		for (Auto auto : vwAL) {	// 5. Ausgabe mit foreach
			System.out.println(auto);
		}
		
		// 6. 
		BMW bmw1 = new BMW("i5", 1980);
		BMW bmw2 = new BMW("i3", 2011);
//		List<Auto> bmwAL = Arrays.asList( (Auto)new BMW("i5", 1980), new BMW("i3", 2011) );
//		ArrayList<Auto> bmwAL = (ArrayList)Arrays.asList((Auto)bmw1, bmw2);
		ArrayList<Auto> bmwAL = new ArrayList<Auto>();
		bmwAL.add(bmw1);
		bmwAL.add(bmw2);
		System.out.println("6. ------------ ArrayList<Auto> bmwAL: --------------");
		for (Iterator<Auto> iterator = bmwAL.iterator(); iterator.hasNext();) {
			Auto auto = (Auto) iterator.next();
			System.out.println(auto);
		}
		
		HashSet<Auto> bmwHS = new HashSet<Auto>();
		bmwHS.add(bmw1);
		bmwHS.add(bmw2);
		System.out.println("6. ------------ HashSet<Auto> bmwHS: --------------");
		Iterator<Auto> iteratorBmwHS = bmwHS.iterator();
		while( iteratorBmwHS.hasNext() ) {
			Auto auto = iteratorBmwHS.next();
			System.out.println(auto);
		}
		
		TreeSet<Auto> bmwTS = new TreeSet<Auto>();
		bmwTS.add(bmw1);
		bmwTS.add(bmw2);
		System.out.println("6. ------------ TreeSet<Auto> bmwTS: --------------");
		for (Auto auto : bmwTS) {
			System.out.println(auto);
		}
		
		// 7. Benutzen Sie die Methode 'contains', um in dem hashSet von BMW-Objekten nach bmw1 zu suchen.
		System.out.println("7. ------------ bmw1 in HashSet mit contains() finden --------------");
		
		String output7 = "bmw1 in HashSet NICHT GEFUNDEN!";
		if ( bmwHS.contains(bmw1) ) {
			output7 = "bmw1 in HashSet bmwHS GEFUNDEN!";
		} // Ergebnis ist true, also bmw1 gefunden.
		System.out.println(output7);
		
		// Alternative zu 7.
//		String output7 = bmwHS.contains(bmw1) ? "bmw1 in HashSet bmwHS GEFUNDEN!" : "bmw1 in HashSet NICHT bmwHS gefunden!";
//		System.out.println(output7);
		
		// 8.
		bmw1.setBaujahr(1999);
		String output8 = bmwHS.contains(bmw1) ? "bmw1 in HashSet bmwHS GEFUNDEN!" : "bmw1 in HashSet NICHT bmwHS gefunden!";
		System.out.println("8. ------------ HashSet mit contains() finden --------------");
		System.out.println(output8);
		// bmwHS.contains(bmw1) ===> Ergebnis: false, bmw1 nicht gefunden.
		// Warum wurde bmw1 nicht gefunden?
		// Antwort: Hash-Wert im HashSet wurde nach Änderung nicht neu berechnet, sondern hat noch Hash-Wert von Baujahr '1980' 
		// Hash-Wert von 'bmw1' in HashSet 'bmwHS' vorhher: -955392490
		// Hash-Wert von 'bmw1' in HashSet 'bmwHS' nachher: -955392490
		
		// 9.
		VW vw9 = new VW("Polo", 2200);
		vwLL.add( vw9 );
//		vwLL.add( new VW("Polo", 2200) );	// anonyme Alternative
		
		// 10.
		System.out.println("10. ------------ VW Polo in LinkedList mit binarySearch() finden --------------");
		System.out.println("The index of the search key is: " + Collections.binarySearch(vwLL, vw9));	// anonyme Alternative
//		System.out.println("The index of the search key is: " + Collections.binarySearch(vwLL, new VW("Polo", 2200) ));
		
		// 11.
		Collections.sort(vwLL);
		System.out.println("11. ------------ LinkedList sortieren und ausgeben --------------");
		for (Iterator<Auto> iterator = vwLL.iterator(); iterator.hasNext();) {
			Auto auto = (Auto) iterator.next();
			System.out.println(auto);
		}
		
		// 12.
		// 	Erst einen Comparator in Klasse Auto implementieren?
		Collections.sort(vwLL, new Auto.DescendingOrder());
		System.out.println("12. ------------ LinkedList reverse sortieren und ausgeben --------------");
		for (Iterator<Auto> iterator = vwLL.iterator(); iterator.hasNext();) {
			Auto auto = (Auto) iterator.next();
			System.out.println(auto);
		}
		
		// 13.
		System.out.println("13. ------------ VW Polo, Baujahr 2200 in LinkedList mit binarySearch() finden --------------");
		System.out.println("The index of the search key is: " + Collections.binarySearch(vwLL, new VW("Polo", 2200), new Auto.DescendingOrder() ));
		// Erklärung: Bei der Suche mit binarySearch das gleiche Suchmuster, 
		// also den gleichen Comparator anwenden, der vorher bei der Sortierung
		// bereits benutzt wurde.
		
		// 14.
		System.out.println("14. ------------ VW Polo, Baujahr 3300 in LinkedList mit binarySearch() finden --------------");
//		System.out.println("The index of the search key is: " + Collections.binarySearch(vwLL, new VW("Polo", 3300)));
		System.out.println("The index of the search key is: " + Collections.binarySearch(vwLL, new VW("Polo", 3300), new Auto.DescendingOrder() ));

	}

}
