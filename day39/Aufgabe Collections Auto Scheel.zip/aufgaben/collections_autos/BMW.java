package aufgaben.collections_autos;

class BMW extends Auto {
	
	BMW (String modell, int baujahr) {
		super(modell, baujahr);
	}
	
//	// Alternative zu 2.
//	@Override
//	public String toString() {
//		return "BMW" + super.toString();
//	}
	
//	// 7. Setter hinzufügen
//	public void setBaujahr(int bj) {
//		baujahr = bj;
//	}
//	
}
