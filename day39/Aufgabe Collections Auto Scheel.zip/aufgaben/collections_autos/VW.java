package aufgaben.collections_autos;

class VW extends Auto {

	VW (String modell, int baujahr) {
		super(modell, baujahr);
	}
	
//	// Alternative zu 2.
//	@Override
//	public String toString() {
//		return "VW" + super.toString();
//	}
	
}
